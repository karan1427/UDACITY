#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include "nav_msgs/Odometry.h"

bool pU = false; //Flag to check if robot reached the Pickup Spot
bool pUd = false; //Pick-up Done
bool dOf = false; //Flag to check if robot reached the Dropoff Spot
bool dOfd = false; //Drop-Off Done

void odomCallBack(const nav_msgs::Odometry::ConstPtr& msg)
{
   //Get the current POSE of the robot
   float pose_x = msg->pose.pose.position.x;
   float pose_y = msg->pose.pose.position.y;
   
   //Check if the positions are closer to pickup nad dropOff locations
   if ((std::abs(0.0 - pose_x) + std::abs((1.0)-pose_y)) < 0.75)
   {
      pU = true; // Robot is at Pick up location
   }
   else if ((std::abs(1.0 - pose_x) + std::abs((5.5)-pose_y)) < 0.75)
   {
      dOf = true; // Robot is at DropOff location
   } 
}
 
int main( int argc, char** argv )
{
   ros::init(argc, argv, "add_markers");
   ros::NodeHandle n;
   ros::Rate r(1);
   //Topic to publish the nodes 
   ros::Publisher marker_pub = n.advertise<visualization_msgs::Marker>("Visualization_Marker", 1);
   
   //Subscribe to /odom of ROBOT to know if the robot has reached the pick-up and drop off locations
   ros::Subscriber robo_sub = n.subscribe("odom", 100, odomCallBack);
    
   //Set our initial shape type to a cube
   uint32_t shape = visualization_msgs::Marker::CUBE;
   
   while (ros::ok())
   {
      visualization_msgs::Marker marker;
      //Set FrameId and timestamp. 
      marker.header.frame_id = "map";
      marker.header.stamp = ros::Time::now();
      
      //Set the namespace and ID for this marker. This serves to create Unique ID 
      //Any marker sent with same namespace and ID will overwrite the old one
      marker.ns = "add_markers";
      marker.id = 0;
      
      //Set the marker type like CUBE, ARROW, SPHERE, CYLINDER
      marker.type = shape;
      
      //Set the marker action like ADD, DELETE 
      marker.action = visualization_msgs::Marker::ADD;
      
      //Set the pose of the marker. This is a full 6DOF pose relative to the frame/time specified in the header
      marker.pose.position.x = 0.0; //PickUp location
      marker.pose.position.y = 1.0; //PickUp location
      marker.pose.position.z = 0;
      marker.pose.orientation.x = 0;
      marker.pose.orientation.y = 0;
      marker.pose.orientation.z = 0;
      marker.pose.orientation.w = 1.0;
      
      //Set the scale of the marker - 1x1x1
      marker.scale.x = 1.0;
      marker.scale.y = 1.0;
      marker.scale.z = 1.0;

      //Set the color - be sure to set a non-zero value to alpha
      marker.color.r = 0.0f;
      marker.color.g = 1.0f;
      marker.color.b = 0.0f;
      marker.color.a = 1.0;
      
      marker.lifetime = ros::Duration();
      
      //Publish the marker 
      while (marker_pub.getNumSubscribers() < 1)
      {
         if (!ros::ok())
         {
            return 0;
         }
         ROS_WARN_ONCE("Please create a subscriber to the MARKER "); 
         sleep(1);
      }
      marker_pub.publish(marker);
      ROS_INFO("Deployed pick-up marker");
      
      //Wait till robot reaches the pickUp spot
      while(!pU)
      {
         ros::spinOnce();
      }
      
      if(true == pU && false == pUd)
      { 
       //Delete the marker 
         marker.action = visualization_msgs::Marker::DELETE;
         marker_pub.publish(marker);
         pUd = true;
         ROS_INFO("Removed the PICKUP Marker. Imitating Pickup");
         ros::Duration(5.0).sleep();
       
       }

      //Wait till robot reaches the DropOff Spot
      while(!dOf)
      {
         ros::spinOnce();
      }
      
      if(true == dOf && false == dOfd)
      { 
         //Display the dropOff Marker
         //Set the pose of the marker. This is a full 6DOF pose relative to the frame/time specified in the header
         marker.pose.position.x = 1.0; //PickUp location
         marker.pose.position.y = 5.5; //PickUp location
         marker.pose.position.z = 0;
         marker.pose.orientation.x = 0;
         marker.pose.orientation.y = 0;
         marker.pose.orientation.z = 0;
         marker.pose.orientation.w = 1.0;
         marker.action = visualization_msgs::Marker::ADD;
         marker_pub.publish(marker);
         ROS_INFO("Deployed Drop-Off Marker");
         dOfd = true; 
         ros::Duration(5.0).sleep();

      }
   return 0;
  }
}

