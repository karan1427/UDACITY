#!/bin/sh
xterm -e " gazebo " &
sleep 4
xterm -e " source /opt/ros/kinetic/setup.bash; roscore" &
sleep 4
xterm -e " rosrun rviz rviz"

