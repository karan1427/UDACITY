Initialized the CATKIN WORKSPACE to inlcude the required packeges.
The source folder contains following packages . Some are cloned and some are created. 
Included gazebo world and map from previous projects.

Cloned Repositories-ROS PACKAGES:
https://github.com/ros-perception/slam_gmapping
Used gmapping_demo.launch file, to perform SLAM and build a map of the environment.

https://github.com/turtlebot/turtlebot
Used keyboard_teleop.launch file, to manually control a robot using keyboard commands.

https://github.com/turtlebot/turtlebot_interactions
Used view_navigation.launch file,to load a preconfigured rviz workspace. This will automatically load the robot model, trajectories, and map for you.

https://github.com/turtlebot/turtlebot_simulator
Used turtlebot_world.launch, to deploy a turtlebot in a gazebo environment and linked my world file to it.

Created Packages:
pick_objects: This will create a node pick_objects; which communicates with the ROS navigation stack and autonomously send successive goals for your TELEOP robot to reach.
In this node, included the action specification for move_base; which is a ROS action. Constructed an action client that we'll use to communicate with the action named "move_base".
We created a goal(pickup) to send to move_base, using the move_base_msgs::MoveBaseGoal message type. Once the goal is reached we send drop off goal to make the robot to move to another location. 

add_markers: Modeled a virtual object with markers in rviz. Added marker at pick up goal location using visualization_msgs/Marker messages, once the robot reached the pickup goal - deleted the marker. When the robot 
reached the dropoff goal, added another marker to show that the robot reached the drop off location. Subscribed to odom values from pick_objects node to monitor the robot's position. 

Added the visualization_marker topic in RVIZ and saved the configuration to launch it with view_navigation.launch file.

Scripts Folder contains following shell scripts to launch terminals for various purposes:
test_slam.sh : To test slam, with manual movements of the turtle teleop robot. 

test_navigation.sh: To test the navigation, by loading or sending our map file to amcl_demo.launch from turtlebot_gazebo package. Goal is set using the 2D Nav GOAL of RVIZ.

pick_objects.sh: To launch pick_objects node along with robot in our world , RVIZ and amcl.

add_markers.sh: To add and remove a marker on the pick up and drop off locationsby launching add_markers node.

home_service.sh: To launch both pick_objects and add_markers nodes together , along with our gazebo world with turtle teleop and acml .  