#!/bin/sh

# launch turtlebot_world.launch in your environment
xterm -e " cd $(pwd)/../..; source devel/setup.bash; roslaunch turtlebot_gazebo turtlebot_world.launch world_file:=$(pwd)/../../src/map/myoffice.world" &
sleep 4

# launch gmapping_demo.launch 
xterm -e " cd $(pwd)/../..; source devel/setup.bash; roslaunch turtlebot_gazebo gmapping_demo.launch" &
sleep 4

# launch view_navigation.launch to observe map in rviz
xterm -e " cd $(pwd)/../..; source devel/setup.bash; roslaunch turtlebot_rviz_launchers view_navigation.launch" &
sleep 4

# launch keyboard_teleop.launch to control robot with keyboard
xterm -e " cd $(pwd)/../..; source devel/setup.bash; roslaunch turtlebot_teleop keyboard_teleop.launch" &
sleep 4
